function navbar(){
    return `  
    <div id="scartnav">
       
    <ul id="scartulnav">
        <li class="li1"><img class="slogo" src="https://www.lybrate.com/img/Lybrate-Goodkart-Logo.png"></li>
        <li class="li2"><input class="scartinputnav" type="text" placeholder="Search for health Products"></li>
        <li class="li3"><select name="" id="scartselect">
        <option value="">Hello,signin</option>
    </select> 
        
    </li>

        <li class="li4"><img class="scartnavicon" src="https://assets.lybrate.com/q_auto,f_auto,h_20,w_20/imgs/product/d2d/PatientGoldMembership/lybrate_icon_red_large.png" alt=""></li><span class="sspan">LybrateCash</span>
        <li class="li5"><button class="shome"><a href="../snavbar.html">Home</a></button></li>
        <li class="li6"><a href="../cart/cart.html"><i class="fa fa-cart-plus" aria-hidden="true"></i><a></li>
        <li class="li7"><i id="user" class="fa fa-user-circle" aria-hidden="true"></i><p class="loginname"></p></li>
    </ul>
</div>
<div id="tdiv">
    <div id="tdiv2">Shop By Category<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" style="height: 250px;">
            <div><i class="fab fa-gratipay"></i>Sexual Wellness</div>
            <hr>
            <div><i class="fas fa-cloud-meatball"></i> Food & Drink</div>
            <hr>
            <div><i class="fas fa-charging-station"></i> Vitamin & Supplement</div>
            <hr>
            <div><i class="fas fa-weight"></i>Weigth Management</div>
            <hr>
            <div><i class="fas fa-child"></i>Child Care</div>
            <hr>
            <div><i class="fas fa-running"></i>Protien & Fitness</div>
            <hr>
            <div><i class="fas fa-allergies"></i>Skin & Health Care</div>
            <hr>
            <div><i class="fas fa-user-check"></i>Personal Care</div>
        </div>
    </div>
    <div id="tdiv2">
        <a>Redeem LybrateCash</a>
    </div>
    <div id="tdiv2">Sexual Wellness<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" class="se"  style="height: 70px;">
            <div>Women Sexual Wellness</div>
            <hr>
            <div>Men Performance Enhancer</div>
        </div>
    </div>
    <div id="tdiv2">Food & Drink<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" class="se"  style="height: 230px;">
            <div>Healthy BreakFast</div>
            <hr>
            <div>Jams,Honey & Spreads </div>
            <hr>
            <div>Ready to Eat</div>
            <hr>
            <div>Healthy Drinks</div>
            <hr>
            <div>Oil & Ghees</div>
            <hr>
            <div>Snack Foods</div>
            <hr>
            <div>Tea & Coffee</div>
        </div>
    </div>
    <div id="tdiv2">Vitamin & Supplement<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" class="se" style="height: 400px;">
            <div><a href="../practise project/liver prod.html">Liver Care</a></div>
            <hr>
            <div><a href="../practise project/multivitanew.html">Multivitamin</a></div>
            <hr>
            <div>Gut Care</div>
            <hr>
            <div>Bones & Joint Care</div>
            <hr>
            <div>Eye Care</div>
            <hr>
            <div>Brain Care</div>
            <hr>
            <div>Hair & Care</div>
            <hr>
            <div>Lung Care</div>
            <hr>
            <div>Menstural Health</div>
            <hr>
            <div>Immunity</div>
            <hr>
            <div>Sleep Aids</div>
            <hr>
            <div>Supplement for Diabetic</div>
        </div>
    </div>
    <div id="tdiv2">Weight Management<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" class="se"  style="height: 100px;">
            <div>Drinks For Weight Loss</div>
            <hr>
            <div>Fat Burner</div>
            <hr>
            <div>Meal Replacement</div>
        </div>
    </div>
    <div id="tdiv2">Child Care<i class="fas fa-angle-down " style="font-size: 10px; color: #FFFFFF;"></i>
        <div id="tdiv3" class="se"  style="height: 200px;">
            <div>Child Skin Products</div>
            <hr>
            <div>Child Hair Shampoo</div>
            <hr>
            <div>Child Bath Essentials</div>
            <hr>
            <div>Child Immunity</div>
            <hr>
            <div>Child Snack Food</div>
            <hr>
            <div>Child Multivitamins</div>
        </div>
    </div>
</div>

`
}
export default navbar