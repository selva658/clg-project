var best=[
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/welark/product_2021-07-14/preworkout_v1.png",
        name:"Wel Ark Muscle & Energy Booster Pre...",
        pnew:"₹1280 ",
        pold:"₹1600 ",
        dis:"20%"
    },
    {
        img:"./2.jpeg",
        name:"Energizes body & enhances sta...",
        pnew:"₹1154 ",
        pold:"₹1649 ",
        dis:"30%",

    },
    {
        img:"./3.jpeg",
        name:"L-Glutamine",
        pnew:"₹1169 ",
        pold:"₹1299 ",
        dis:"10%",

    },
    {
        img:"./4.jpeg",
        name:"Onelife Glutamine Green Apple...",
        pnew:"₹999 ",
        pold:"₹1749 ",
        dis:"42%",

    }
]
var newArrival=[
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/zerobeli/lot2/zerobeli_strwbry_cornflake_pack.png",
        name:"Zerobeli Real Strawberry Corn Flakes...",
        pnew:"₹790 ",
        pold:"₹1050 ",
        dis:"24%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/namyaa/lot2/qraa_dynamo_pack.png",
        name:"Qraa Men Dynamo Power 30 Cap...",
        pnew:"₹574 ",
        pold:"₹780",
        dis:"26%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/namyaa/lot2/qraa_liverstrong_v1.png",
        name:"Qrra Men Liver Strong Capsules 30 C...",
        pnew:"₹279 ",
        pold:"₹349",
        dis:"20%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/kalon/18july_21/strawber_hfs_v1.png",
        name:"Kalon Starwberry Honey Fruit(...",
        pnew:"₹316 ",
        pold:"₹395 ",
        dis:"20%",
    }
]

var Money=[
    {
        img:"https://th.bing.com/th/id/OIP.IagLutZik1xmYB6BQTnDlAHaHa?w=192&h=192&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Add Veda Add Sperm (60 Capsules)",
        pnew:"₹1500 ",
        pold:"₹3000 ",
        dis:"50%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/healthvit/wchv_zinc_gluconate.jpg",
        name:"Healthvit Zinc Gluconate",
        rate:null,
        pnew:"₹599 ",
        pold:"₹1400",
        dis:"57%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white//rio/800x800/Haironic1_v10.jpg",
        rate:"4.4",
        name:"Hair Growth Supplement",
        pnew:"₹299 ",
        pold:"₹400 ",
        dis:"25%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/3M_designs/Product-Images/image-016.webp",
        name:"Pyrexofly",
        pnew:"₹210 ",
        pold:"₹250 ",
        dis:"16%",
    }
]
var sexwell=[
    {
        img:"https://th.bing.com/th/id/OIP.fbRW5qf3u7NrCu1X6iwRqgHaJp?w=180&h=217&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        rate:"4.9",
        name:"Ashwa Ginseng",
        pnew:"₹1079 ",
        pold:"₹1499 ",
        dis:"28%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_230,c_pad,b_white/rio/800x800/Stemno-1.webp",
        rate:"4.8",
        name:"Stemno Capsules",
        pnew:"₹1100 ",
        pold:"₹1500 ",
        dis:"26%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_230,c_pad,b_white/rio/namyaa/lot2/namyaa_shwet_pack.png",
        name:"Namyaa ShwetKanika For White...",
        pnew:"₹668 ",
        pold:"₹898 ",
        dis:"25%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_230,c_pad,b_white/rio/namyaa/lot2/namyaa_anartava_pack.png",
        name:"Namyaa Anartava For Delayed & irreg...",
        pnew:"₹748 ",
        pold:"₹998",
        dis:"25%",
    },

]
var immunity=[
    {
        img:"https://th.bing.com/th/id/OIP.4bC0edzrLAsDH_kCnl_fNQHaHg?w=173&h=180&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        rate:"4.3",
        name:"Enviro Chip for Laptop(Black)",
        pnew:"₹1099 ",
        pold:"₹1399 ",
        dis:"21%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.cskYbxLX-nlCQi83RyWtxgHaEK?w=296&h=180&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Amrit Kalash Dual Pack",
        pnew:"₹1049 ",
        pold:"₹1100",
        dis:"4%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.ot8rRnyl56HNAZ4bTN7z9QHaHa?w=158&h=181&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Morning Vital 60 Capsules",
        pnew:"₹899 ",
        pold:"₹1199 ",
        dis:"25%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/3M_designs/Product-Images/image-016.webp",
        rate:"4.3",
        name:"Pyrexofly",
        pnew:"₹210 ",
        pold:"₹250 ",
        dis:"16%",
    }
]
var weight=[
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_230,c_pad,b_white//rio/800x800/slimherb1_v10.jpg",
        rate:"4.4",
        name:"Herbal vibe Slim Herbs",
        pnew:"₹805 ",
        pold:"₹1750 ",
        dis:"54%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/purenutri/prod_2021-04-22/applecider-v1.webp",
        name:"Apple Cide Vinegar Plus",
        pnew:"₹760 ",
        pold:"₹1199 ",
        dis:"36%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.ZFrmQRLLwrF2YxQMO1lX0AHaHa?w=187&h=187&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        rate:"4.6",
        name:"Farm Naturella Organic Apple Cider...",
        pnew:"₹500 ",
        pold:"₹625 ",
        dis:"20%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.UaAdk2aXe78cSxGHKF3aMQHaHa?w=214&h=214&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        rate:"4.8",
        name:"Suprabhat Tea-Lemongrass Balck Tea",
        pnew:"₹600 ",
        pold:"₹700 ",
        dis:"14%",
    }
]
var vitamins=[
    {
        img:"https://th.bing.com/th/id/OIP.QM7wMFHPc3L3n9lgcadKGQHaHa?w=217&h=217&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Three B",
        pnew:"₹549 ",
        pold:"₹720 ",
        dis:"23%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/onelife/olmp_bone_bliss.jpg",
        name:"Onelife bone Bliss",
        pnew:"₹449 ",
        pold:"₹949 ",
        dis:"52%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.nbz6lN-wCoBoUz2xaOFRHQHaHg?w=195&h=197&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Add Veda Bio Ortho Capsule(60 Caps...",
        pnew:"₹800 ",
        pold:"₹900 ",
        dis:"11%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white//rio/800x800/Haironic1_v10.jpg",
        rate:"4.4",
        name:"Hair Growth Supplement",
        pnew:"₹299 ",
        pold:"₹400 ",
        dis:"25%",
    }
]
var coffee=[
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/namhya/thyroid_care_v1.png",
        name:"Namhya Thyroid Care Tea 100g",
        pnew:"₹549 ",
        pold:"₹589 ",
        dis:"6%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_300,c_pad,b_white/rio/butterfly/annual/masala_back.jpg",
        rate:"4.9",
        name:"Msala Chai (20 Tea Bags)",
        pnew:"₹500 ",
        pold:"₹600 ",
        dis:"16%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.UaAdk2aXe78cSxGHKF3aMQHaHa?w=214&h=214&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        rate:"4.8",
        name:"Suprabhat Tea - Lemongrass Black Tea",
        pnew:"₹600 ",
        pold:"₹700 ",
        dis:"14%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/butterfly/annual/tea-potpourri.jpg",
        rate:"4.8",
        name:"Tea Potpourri Tea Bags",
        pnew:"₹275",
        pold:"₹335 ",
        dis:"17%",
    }
]
var hair=[
    {
        img:"https://th.bing.com/th/id/OIP.3Di7ir2fDXhdWFh5itxuTwHaHa?w=185&h=185&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Mister Hair Growth pack for Men",
        pnew:"₹699 ",
        pold:"₹999 ",
        dis:"30%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white//rio/800x800/regrowoil1_v10.jpg",
        rate:"4.4",
        name:"Auggmin Regrow Hair Oil ",
        pnew:"₹750 ",
        pold:"₹2000 ",
        dis:"62%",
    },
    {
        img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_200,c_pad,b_white/rio/800x800/Heel-Repair-1.webp",
        name:"HeelRepair Cream",
        pnew:"₹500 ",
        pold:"₹708 ",
        dis:"29%",
    },
    {
        img:"https://th.bing.com/th/id/OIP.RIaDdjOuqZ74Kt-J2s8jTAHaHa?w=300&h=200&c=7&r=0&o=5&dpr=1.25&pid=1.7",
        name:"Fungicid Gel",
        pnew:"₹500 ",
        pold:"₹700 ",
        dis:"28%",
    }
]
// var exchange=[
//     {
//         img:"https://assets.lybrate.com/q_auto,f_auto,w_300,h_300,c_pad,b_white/rio/3M_designs/Product-Images/image_012.webp",
//         name:"Fight acne & blemishes!",
//         pnew:"₹99",
//         pold="₹599",
//        dis:null,
//     },
//     {
//         img:"https://th.bing.com/th/id/OIP.Tb_9r1zNoLGva9_fs11-RgHaKj?w=304&h=219&c=7&r=0&o=5&dpr=1.25&pid=1.7",
//         name:"Lipoherb:Ayurvedic Medicine for wei...",
//         pnew:"₹1",
//         pold="₹180",
//        dis:null,
//     }
// ]
function webpage(data,location){
    data.map(function (el){
        var div=document.createElement("div");
        var img=document.createElement("img");
        var p0=document.createElement("p");
        var p=document.createElement("p");
        var p1=document.createElement("p");
        var p2=document.createElement("p");
        var p3=document.createElement("p");
        img.src=el.img;
        p0.textContent=el.rate;
        p0.setAttribute("id","rating")
        p.textContent=el.name;
        var div1=document.createElement("div");
        p1.textContent=el.pnew;
        p2.textContent=el.pold;
        p3.textContent=el.dis;
        div1.append(p1,p2,p3);
        if(el.rate==null)
        {
            div.append(img,p,div1);
        }else{
            div.append(img,p0,p,div1);
        }
        location.append(div);
    }) 
}

function descript(){
    return ` <div>
    <div><a href="#">Home</a> > GoodKart</div>
    <h3>GoodKart: Buy Health Care and Wellness Products Online</h3>
    <p>GoodKart is Lybrate’s endeavour to deliver the best of the best Health care products at your doorstep. GoodKart brings to you a vibrant mix of health products, 
        both from reputed international brands to local Indian brands. We feel privileged to offer you the convenience to buy these health care products 24*7 from the 
        comfort of your home through GoodKart. Determined to offer a better choice to our citizens, Lybrate is working against all odds for bringing you specially curated 
        top of the line health products. We firmly believe that healthy living starts with a healthy body and a sound mind.</p>
    <p>GoodKart promises to provide a great deal of transparency to its users. To fulfill this endeavor, we have compiled truly remarkable products from reliable manufacturers.
    Most of our health care product ingredients are extracted in a very responsible manner to ensure that all the natural properties remain intact. GoodKart makes it very convenient
    for its users to find the really good stuff. We bring to you the goodness of nature discovered through research. Staying true to our commitment of providing top, trending, recommended, 
    popular, safe, gentle, and effective products infused with the goodness of mother earth, we consistently keep expanding our health care products list, enabling our users to save time & money both.</p>
    <p>At GoodKart, we bring to you not only the natural health care products but also different ayurvedic and herbal products to help you address various health concerns 
               and issues. Shop health and wellness products online without standing in any queue. Buy health care products safely and securely with great discounts and cashback 
               offers only at GoodKart.</p>
         <h4>Buy Natural Health Products From Lybrate’s GoodKart</h4>
         <p>As consumers of GoodKart, you can browse health products from a comprehensive assortment of Vitamins and Supplements, Protein & Fitness, Skin & Hair Care, Sexual Wellness, 
                   Weight Management, Food & Drinks, Personal Care and Child Care Products. Not only these wellness products give you exceptional results but they are also extremely 
                   cost-effective due to Lybrate’s unique sourcing model. Today’s aware consumers prefer to know their products in terms of ingredients, sourcing of raw materials, 
                   manufacturer’s goodwill to make informed choices. Such consumer behavior has forced most of today’s manufacturers to come up with ingenious ways of manufacturing 
                   safe and best health care products. This consumerism also has to lead to a lot of companies making false promises to lure more customers and increase revenue.</p>
         <h3>VITAMIN AND SUPPLEMENTS - SAFE, EFFECTIVE & EASY TO CONSUME</h3>
         <p>Managing stress, cleansing your body, nourishing your cells & tissues with all the essential nutrients is key to a healthy & active lifestyle. 
                       High-quality vitamins & supplements are available at GoodKart that provide the necessary nourishment needed to restore your body and bring 
                       about optimal health and positivity. The principle is very simple, the best supplements, honest expert advice, quality service, and incredibly 
                       effective products. We hope we have earned your trust as a health care partner in taking control of your wellness goals.</p>
         <h3>NUTRIENT SUPPLEMENTS</h3>
         <p>Good Health and Wellness depend on a lot of factors such as genetics and environment, however, a lot has to do with 
                           our dietary habits and nutrient intake. The harsh truth is that it is really difficult to consume all the nutrients 
                           we need, due to lifestyle, lack of awareness and regional dietary patterns. We require supplements apart from our 
                           daily food intake to ensure that we are nourished. Here at GoodKart, a variety of vitamins and supplements are available 
                           from which you can choose as per your requirements. We advise you to read the labels of the product descriptions carefully 
                           to ensure that you do not miss out on the most critical ingredients you are looking for.</p>
         <h3>PROTEIN AND FITNESS PRODUCTS FOR SEVERAL FITNESS REGIMENS</h3>
         <p>Goodkart also brings to you some of the most sought after quality Protein & Fitness products which are suitable for 
                               people from all walks of life, including those on vegan diets, low carbohydrate diets or for those with gastrointestinal 
                               sensitivities to milk or any other protein sources for that matter. GoodKart aim’s to be a part of your fitness 
                               journey. GoodKart helps you choose from the widest range of healthy protein and fitness products. Get detailed 
                               product information such as nutritional content along with when, how and why to use details is provided. This makes 
                               selecting products easier and convenient. We ensure that our users invest only in authentic natural health products 
                               to help them achieve their fitness goals.</p>
         <h3>SKIN CARE PRODUCTS FOR HEALTHY SKIN</h3>
         <p>This should not come as a surprise that the Skin and Hair Care beauty market is exploded with tonnes of 
                               products, both organic & synthetic. GoodKart features an amazing collection of Skincare products that 
                               make a difference in your lives. We feel proud to be associated with manufacturers who ensure that 
                               cutting edge therapeutic benefits are delivered to your skin. GoodKart’s users can choose from a variety 
                               of alternatives for all of their skincare requirements. Most of the Skin and Hair care products available at 
                               our platform are derived from natural sources, not from a laboratory. So, you get to experience the goodness 
                               of wholly natural ingredients. Skincare products interact sympathetically with your skin and also carry therapeutic benefits as well.</p>
         <h3>SEXUAL WELLNESS PRODUCTS TO ENHANCE YOUR SEXUAL LIFE</h3>
         <p>Taking care of your sexual health has become simple with online gateways like GoodKart, which has all the sexual wellness 
                                   products under one roof. Every individual has a distinct way to maintain their sexual health. GoodKart is stacked with 
                                   a variety of intimate care products and wellness supplements, which are scientifically proven and safe with absolutely 
                                   no side effects. Most people do not like to talk about intimate hygiene and sexual health care, for the sexual wellbeing 
                                   products, are a blessing in disguise.</p>
         <h3>PICK HERBAL AND NATURAL WEIGHT MANAGEMENT PRODUCTS</h3>
         <p>If you need help in searching for the perfect product and health care brands that can assist you in your weight loss 
                                       and gain journey, then check out GoodKart Weight Management Products to help support recovery from your weight 
                                       training. Choose from an ever-increasing list of weight management products to help you shed those extra kilos 
                                       and fit in your favorite pair of jeans. The natural extracts, herbal ingredients, and the right dosage count for 
                                       giving serious results if you are trying weight loss and gain journey.</p>
         <h3>OPT FOR PICK HEALTHY FOOD AND DRINKS PRODUCTS</h3>
         <p>Due to hectic routine and fast-paced lives, we generally tend to neglect our health. We easily get enticed to sugary food and 
             caffeinated drinks which harms our health. As a health care platform, we believe that food should be Natural and Organic. 
             We aim to take steps towards a better and healthier planet. We have Organic Food and Healthy drinks which are good for one’s 
             health - not a mere convenience. GoodKart brings different health care products at your doorstep. An incredible range of Food 
             and Drinks are available for every health-conscious family.</p>
         <p>Nutritional drinks offer numerous health benefits to both children and grown-ups. They help in physical and mental development, 
             improve resistance, sustenance, stamina, and energy by nourishing the body with all the vital nutrients and minerals. Healthy 
             drinks are immensely useful when you are struggling to manage your daily lack of supplement intake. All these healthy food and 
             drink products available at Goodkart are best for sudden hunger cravings and as an evening snack.</p>
         <h3>CHECK OUT PERSONAL CARE PRODUCTS FOR OVERALL WELL-BEING</h3>
         <p>You can choose from a wide range of personal health care products online at GoodKart. One-stop avenue for all your essential 
             personal care needs. We have worked out to perfection on all the relevant yet diverse aspects of bringing personal care 
             products to our consumers devoid of any harmful chemicals. Right from selecting the ingredients, the processing, the right 
             storage, and packaging, we pay attention to every minute detail. Most of these health products are vegan and cruelty-free. 
             They are not tested on animals and do not cause any damage to the environment. Listed personal health care products are also 
             free of synthetic perfumes, herbicides and pesticides.</p>
         <h3>KEEP YOUR CHILD HEALTHY WITH CHILD CARE PRODUCTS ONLINE</h3>
         <p>Good Health is the foundation of all things good and godly and should be looked after from an early age. Whether it’s bubble 
             baths or bed snuggles, these everyday rituals with your baby become better if the right senses such as smell and touch are 
             stimulated. GoodKart has an assortment of Child care products that are 100% gentle and safe for your little one. The most 
             trusted names in the field of baby care are affiliated with GoodKart. Health care products are clinically proven safe and 
             have a very gentle formulation. At GoodKart, we only have health products that have purer ingredients and are best for the 
             delicate skin of your baby.</p>
         <h3>BEST HEALTH CARE AND WELLNESS PRODUCTS AT LYBRATE’S GOODKART</h3>
         <p>At Goodkart, you can buy the best health care supplements online, under one roof for Men, Women, and children. We offer 
             consumer-friendly prices on health and wellness products online. Shop for natural health products from Goodkart platform 
             at best prices, get different great Combo deals, discounts, fast shipping, and Lybrate cashback offers. GoodKart offers 
             you the choice to pick from various health care brands and quality health care products online that can definitely make 
             a difference when it comes to health fitness and overall well being.</p>
         <h3>GET LYBRATE CASHBACK</h3>
         <p>LybrateCash is your health money at Lybrate. By utilizing LybrateCash, you can pay for your health needs and avail it 
             for buying healthcare products, booking online specialist consultation and lab tests.</p>
         <ol>
             <li>One LybrateCash point is equivalent to ₹1.</li>
             <li>Lybrate is giving 10% cashback as a LybrateCash to its registered users when they buy any product. 
                 The cashback is credited to your LybrateCash account.</li>
             <li>You can keep a check on the expiry date of the LybrateCash earned by checking your LybrateCash history.</li>
             <li>You can't transfer this cash to any other financial wallet or to another user.</li>
             </ol>
         <h3>RETURN AND REFUND POLICY</h3>
         <p>At Lybrate.com, we do our best to ensure that our customers are immensely satisfied with our products. 
             And we are happy to offer a complete refund in the following circumstances.</p>
         <ol>
             <li>You received a defective/damaged item(s).</li>
             <li>Delivered item(s) doesn't match your order.</li>
             <li>The ordered item(s) is/are lost or damaged during transit.</li>
             <li>The ordered item(s) is/are beyond its expiry date.</li>
         </ol>
         <h4 style:"font-weight:bold;">Following circumstances do not qualify for Return or Refund.</h4>
         <ol>
             <li>Return or Refunds are not applicable on products which are ordered incorrectly or by mistake.</li>
             <li>Return or Refunds are not applicable on products which are not required by the users due to change in prescription.</li>
             <li>Products without the original label, tag, invoice and bar code are not eligible for returns or refunds.</li>
             <li>All products which have been used/opened, either partially or fully, do not qualify for return or refund.</li>
             <li>Return product should have the same batch number as mentioned on the invoice.</li>
             <li>Non-delivery of product reported after 48 hours of delivery confirmation text message on registered mobile number are not eligible for refund.</li>
         </ol>
         <h3>HOW TO REQUEST A REFUND?</h3>
         <p>To request a refund, simply email us your order details, including the reason why you’re requesting a refund at orders@lybrate.com</p>
         <p><span style="font-weight: bold;">Please Note</span>: Mode of refund may vary from case to case. If the mode of refund is by Credit/Debit Card or Net Banking, allow 7 to 14 
             working days for the credit to appear in your account. If the mode of refund is by Wallet, credit should be available within 7 to 
             10 working days.</p>
         <p><span style="font-weight: bold;">Disclaimer</span>: While we ensure that all product information on the platform is complete and accurate, however, we advise you not to 
             solely rely on this information. It is recommended to refer to the product manual and/or specifications provided by the manufacturer 
             either on their website or along with the product. This is applicable for all warnings, labels, ingredients and usage directions as well. 
             The use of any information provided on this platform is solely at the user's risk. Nothing contained on this platform shall be considered 
             as medical advice. Consumers are advised to contact the manufacturer for any further information and assistance. The results from the products 
              will vary from person to person, No individual result should be seen as typical.</p>
</div>`
}
export {webpage,descript,best,newArrival,Money,sexwell,immunity,weight,vitamins,coffee,hair};