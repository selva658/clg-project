let footer = () => {
    return `
    <div id="sfooterbg">
    <div id="swholefooter">
    <div id="sfooter">
    
    
    <ul class="unstyled">
        <li class="sfooterlitag1">DELHI</li>
        <li class="sfooterlitag"><a target="_self" href="" >Dentist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="" >General Physicians in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="" >Cardiologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="" >Gynaecologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="" >Psychiatrist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="" >Dermatologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="">Neurologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="">Urologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="">Ophthalmologist in Delhi</a></li>
        <li class="sfooterlitag"><a target="_self" href="">Sexologist in Delhi</a></li>
      </ul>
    
    
      <!-- 2nd -->
    
      
        <ul class="unstyled">
              <li class="sfooterlitag1">MUMBAI</li>
            <li class="sfooterlitag"><a target="_self" href="" >Dentist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">General Physicians in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Cardiologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Gynaecologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Psychiatrist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Dermatologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Neurologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Urologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Ophthalmologist in Mumbai</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Sexologist in Mumbai</a></li>
        </ul>
     
    
        <!-- 3rd -->
    
        
            <ul class="unstyled">
                <li class="sfooterlitag1">CHENNAI</li>
                <li class="sfooterlitag"><a target="_self" href="">Dentist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">General Physicians in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Cardiologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Gynaecologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Psychiatrist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Dermatologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Neurologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Urologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Ophthalmologist in Chennai</a></li>
                <li class="sfooterlitag"><a target="_self" href="">Sexologist in Chennai</a></li>
            </ul>
    
        <!-- 4th -->
    
        <ul class="unstyled">
            <li class="sfooterlitag1">BANGALORE</li>
            <li class="sfooterlitag"><a target="_self" href="">Dentist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">General Physicians in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Cardiologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Gynaecologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Psychiatrist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Dermatologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Neurologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Urologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Ophthalmologist in BANGALORE</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Sexologist in BANGALORE</a></li>
        </ul>
    
    
        <!-- 5th -->
    
        
        <ul class="unstyled">
            <li class="sfooterlitag1">Lybrate.com</li>
            <li class="sfooterlitag"><a target="_self" href="">About Us</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Contact Us</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Careers</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Mobile Apps</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Blog</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Terms of Use</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Privacy Policy</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Editorial Policy</a></li>
            <li class="sfooterlitag"><a target="_self" href="">Press</a></li>
        </ul>
    </div>
    <div class="footer-outer">
        <div class="left">
            <a href="" class="footer-item1" target="_self">City Index</a>
            <a href="" class="footer-item" target="_self">Locality City Index</a>
            <a href="" class="footer-item" target="_self">Specialty Index</a>
            <a href="" class="footer-item" target="_self">Specialty City Index</a>
            <a href="" class="footer-item" target="_self">Health Wiki</a>
            <a href="" class="footer-item" target="_self">Health Tips Index</a>
            <a href="" class="footer-item" target="_self">Health Questions Index</a>
            <a href="" class="footer-item" target="_self">Health Quizzes Index</a>
            <a href="" class="footer-item" target="_self">Health Topics Index</a>
            <a href="" class="footer-item" target="_self">Medicines Index</a>
            <a href="" class="footer-item" target="_self">Ailment Index</a>
            <a href="" class="footer-item" target="_self">Health Packages</a>
            <a href="" class="footer-item" target="_self">Lab Test Details Index</a>
            <a href="" class="footer-item" target="_self">Treatment Pages Index</a>
            <a href="" class="footer-item" target="_self">Patient Support Programs</a>               
        </div>
    
    </div>
    
    <div class="sfootercopyrights">
        © 2020 Lybrate, Inc. All rights reserved.
        <span class="sfootericon1"><i class="fa fa-facebook" aria-hidden="true"></i></span>
        <span class="sfootericon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
        <span class="sfootericon"><i class="fa fa-linkedin" aria-hidden="true"></i></span>
        <span class="sfootericon"><i class="fa fa-youtube-play" aria-hidden="true"></i></span> 
    </div>
    </div>
    </div>
    `
}


export default footer